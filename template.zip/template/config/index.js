module.exports = {
    globalVariable: ['App', 'Page', 'getApp', 'swan'],
    xmlType: /\.(wxml|axml|swan)(\?.*)?$/
};